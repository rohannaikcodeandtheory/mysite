/**
 * Choose a completely separate secret set for each approved public hostname.
 * A single EDS configuration pipeline can serve stage and production.
 * Local loopback uses Stage *dummy* values when running the Fastly CLI.
 */
import { fail } from './errors.js';

export function selectEnvironment(hostname, { stageHost, prodHost }) {
  const host = String(hostname || '').toLowerCase();
  if (host === '127.0.0.1' || host === 'localhost') return 'STAGE';
  if (stageHost && host === stageHost.toLowerCase()) return 'STAGE';
  if (prodHost && host === prodHost.toLowerCase()) return 'PROD';
  fail('HOST_NOT_ALLOWED', 'This endpoint is not enabled on this hostname', 403);
}
