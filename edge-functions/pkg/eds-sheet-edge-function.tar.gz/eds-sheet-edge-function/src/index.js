/// <reference types="@fastly/js-compute" />
import { ConfigStore } from 'fastly:config-store';
import { SecretStore } from 'fastly:secret-store';
import { createHandler } from './handler.js';
import { selectEnvironment } from './runtime-settings.js';

/** Fastly/AEM Edge Functions entrypoint; no Node APIs or secrets embedded. */
async function handleRequest(request) {
  try {
    const config = new ConfigStore('config_default');
    const secrets = new SecretStore('secret_default');
    const stageHost = config.get('STAGE_API_HOST') || '';
    const prodHost = config.get('PROD_API_HOST') || '';
    const env = selectEnvironment(new URL(request.url).hostname, { stageHost, prodHost });
    // Adobe's EDS secret store may expose individual keys or a JSON "secrets" bundle.
    let secretBundlePromise;
    async function readRawSecret(key) {
      if (!secretBundlePromise) {
        secretBundlePromise = (async () => {
          try {
            const entry = await secrets.get('secrets');
            const bundle = entry ? JSON.parse(entry.plaintext()) : null;
            return bundle && typeof bundle === 'object' ? bundle : {};
          } catch { return {}; }
        })();
      }
      const bundle = await secretBundlePromise;
      if (typeof bundle[key] === 'string') return bundle[key];
      try {
        const entry = await secrets.get(key);
        return entry ? entry.plaintext() : null;
      } catch { return null; }
    }
    const getSecret = (key) => readRawSecret(`${key}_${env}`);
    const handle = createHandler({
      getSecret,
      fetcher: fetch,
      settings: {
        org: config.get('DA_ORG') || '',
        site: config.get('DA_SITE') || '',
        scopes: config.get(`IMS_SCOPES_${env}`) || '',
        allowedHost: env === 'STAGE' ? stageHost : prodHost,
      },
    });
    return await handle(request);
  } catch (error) {
    // Do not print token or secret values; reject missing edge configuration safely.
    const isHost = error?.code === 'HOST_NOT_ALLOWED';
    return new Response(JSON.stringify({ success: false,
      error: { code: isHost ? 'HOST_NOT_ALLOWED' : 'EDGE_FUNCTION_UNAVAILABLE',
        message: isHost ? 'This hostname is not enabled' : 'Edge Function configuration unavailable' } }), {
      status: isHost ? 403 : 503,
      headers: { 'content-type': 'application/json', 'cache-control': 'no-store' },
    });
  }
}
addEventListener('fetch', (event) => event.respondWith(handleRequest(event.request)));
